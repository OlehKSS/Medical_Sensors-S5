2D PHASE UNWRAPPING ALGORITHMS

Run QualityGuidedUnwrap2D for the phase quality guided phase unwrapping method.

Run GoldsteinUnwrap2D for Goldstein's branch cut phase unwrapping method.

(3D implementation of the quality guided method available on request)